package com.cg.registration.client;

import java.sql.Connection;
import java.util.InputMismatchException;
import java.util.Scanner;





import com.cg.registration.dao.RegistrationDAOImpl;
import com.cg.registration.exception.InvalidInputException;
import com.cg.registration.exception.RegistrationServiceDownException;
import com.cg.registration.service.RegistrationService;
import com.cg.registration.service.RegistrationServiceImpl;
import com.cg.registration.util.ConnectionProvider;



public class Client {
public static void main(String arg[]) throws RegistrationServiceDownException, InvalidInputException{
	if (ConnectionProvider.getDBConnection() != null)
		System.out.println("Successfully Connected");
	else
		System.out.println("Not Connected");
	
	RegistrationService registrationService=new RegistrationServiceImpl();
	int choice=0;
	Scanner sc=new Scanner(System.in);
	System.out.println("1.Enter registration details:");
	System.out.println("2.Exit");
try {
	choice = sc.nextInt();
	while(choice==1){
		System.out.println("Enter the name of the customer : ");
		sc.nextLine();
		String customerName = sc.nextLine();
		System.out.println("Enter customer mobile number: ");
		String mobileNumber = sc.nextLine();
		if(mobileNumber.length()!=10)
			throw new InvalidInputException("Please enter valid input.");
		
		System.out.println("Enter Registration Fee: ");
		Double registrationFee = sc.nextDouble();
		System.out.println("Enter age: ");
		int age = sc.nextInt();
		
		int registrationId=registrationService.addRegistrationDetails(customerName, mobileNumber, age, registrationFee);
		System.out.println("Your Registration is complete");
		System.out.println(registrationService.getRegistrationDetails(registrationId));// this line prints the registration details
		
	}}catch(InputMismatchException e){
	System.out.println("Please enter valid input.");
}
}

	

}
