package com.cg.registration.dao;

import java.sql.SQLException;

import com.cg.registration.bean.Customer;

public interface RegistrationDAO {
public int addRegistrationDetails(Customer registration) throws SQLException;
public Customer getRegistrationDetails(int registrationId)  throws SQLException;
}
