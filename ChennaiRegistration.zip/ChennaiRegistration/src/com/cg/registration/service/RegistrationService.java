package com.cg.registration.service;

import com.cg.registration.bean.Customer;
import com.cg.registration.exception.RegistrationServiceDownException;

public interface RegistrationService {
	public int addRegistrationDetails(String customerName,String mobileNumber,int age,double registrationFee) throws RegistrationServiceDownException;
 public Customer getRegistrationDetails(int registrationId) throws RegistrationServiceDownException;
}
