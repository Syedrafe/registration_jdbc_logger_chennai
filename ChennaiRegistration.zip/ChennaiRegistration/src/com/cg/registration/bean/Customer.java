package com.cg.registration.bean;

public class Customer {

	private int registrationId;
	private String customerName;
	private String mobileNumber;
	private double registrationFee;
	private int age;
	private double actualFee;
	public Customer(int registrationId, String customerName,
			String mobileNumber, double registrationFee, int age,
			double actualFee) {
		super();
		this.registrationId = registrationId;
		this.customerName = customerName;
		this.mobileNumber = mobileNumber;
		this.registrationFee = registrationFee;
		this.age = age;
		this.actualFee = actualFee;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(String customerName2, String mobileNumber2, int age2,
			double registrationFee2) {
		// TODO Auto-generated constructor stub
	}
	public Customer(String customerName2, String mobileNumber2, int age2,
			double registrationFee2, double actualFee2) {
		super();
		
		this.customerName = customerName2;
		this.mobileNumber = mobileNumber2;
		this.registrationFee = registrationFee2;
		this.age =  age2;
		this.actualFee = actualFee2;
	}
	public int getRegistrationId() {
		return registrationId;
	}
	public void setRegistrationId(int registrationId) {
		this.registrationId = registrationId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public double getRegistrationFee() {
		return registrationFee;
	}
	public void setRegistrationFee(double registrationFee) {
		this.registrationFee = registrationFee;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public double getActualFee() {
		return actualFee;
	}
	public void setActualFee(double actualFee) {
		this.actualFee = actualFee;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(actualFee);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + age;
		result = prime * result
				+ ((customerName == null) ? 0 : customerName.hashCode());
		result = prime * result
				+ ((mobileNumber == null) ? 0 : mobileNumber.hashCode());
		temp = Double.doubleToLongBits(registrationFee);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + registrationId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (Double.doubleToLongBits(actualFee) != Double
				.doubleToLongBits(other.actualFee))
			return false;
		if (age != other.age)
			return false;
		if (customerName == null) {
			if (other.customerName != null)
				return false;
		} else if (!customerName.equals(other.customerName))
			return false;
		if (mobileNumber == null) {
			if (other.mobileNumber != null)
				return false;
		} else if (!mobileNumber.equals(other.mobileNumber))
			return false;
		if (Double.doubleToLongBits(registrationFee) != Double
				.doubleToLongBits(other.registrationFee))
			return false;
		if (registrationId != other.registrationId)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Registration [registrationId=" + registrationId
				+ ", customerName=" + customerName + ", mobileNumber="
				+ mobileNumber + ", registrationFee=" + registrationFee
				+ ", age=" + age + ", actualFee=" + actualFee + "]";
	}
	
}
