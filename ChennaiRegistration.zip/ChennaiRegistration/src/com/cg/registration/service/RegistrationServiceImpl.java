package com.cg.registration.service;

import java.sql.SQLException;

import com.cg.registration.bean.Customer;
import com.cg.registration.dao.RegistrationDAO;
import com.cg.registration.dao.RegistrationDAOImpl;
import com.cg.registration.exception.RegistrationServiceDownException;

public class RegistrationServiceImpl  implements RegistrationService{
private RegistrationDAO registrationdao=new  RegistrationDAOImpl();
	@Override
	public int addRegistrationDetails(String customerName, String mobileNumber,int age,double registrationFee) throws RegistrationServiceDownException {
		try {
			   
			   double actualFee=0;
			   if(age<18)
				   actualFee= registrationFee;
			   else if(age>=18 && age<25)
				   actualFee= registrationFee-registrationFee*0.1;
			   else if(age>=25 && age<50)
				   actualFee= registrationFee-registrationFee*0.2;
			   else if(age>=50)
				   actualFee= registrationFee/2;
			Customer customer=new Customer(customerName,mobileNumber,age,registrationFee,actualFee);
			return registrationdao.addRegistrationDetails(customer);
		} catch (SQLException e) {
			throw new RegistrationServiceDownException("Registration Server is down tey again later");
		}
		
	}

	@Override
	public Customer getRegistrationDetails(int registrationId) throws RegistrationServiceDownException {
		Customer customer;
		try {
			customer=registrationdao.getRegistrationDetails(registrationId);
			return customer;
		} catch (SQLException e) {
			throw new RegistrationServiceDownException("Registration Server is down tey again later");
		}
	}

}
