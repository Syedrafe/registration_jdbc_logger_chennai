package com.cg.registration.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import com.cg.registration.bean.Customer;
import com.cg.registration.util.ConnectionProvider;

public class RegistrationDAOImpl implements RegistrationDAO {
private Connection conn=ConnectionProvider.getDBConnection();
private static final Logger logger = Logger.getLogger(RegistrationDAOImpl.class);
	@Override
	public int addRegistrationDetails(Customer registration) throws SQLException{
		try {
			conn.setAutoCommit(false);
			PreparedStatement pstmt1 =conn.prepareStatement("INSERT INTO registration(registration_id,customer_name, mobile_number,registrations_fee, age ,actual_fee) values (Transaction_Id_Seq.nextVal,?,?,?,?,?)");
			pstmt1.setString(1, registration.getCustomerName());
			pstmt1.setString(2,registration.getMobileNumber());
			pstmt1.setDouble(3,registration.getRegistrationFee());
			pstmt1.setInt(4,registration.getAge());
			pstmt1.setDouble(5,registration.getActualFee());
			pstmt1.executeUpdate();
			conn.commit();
			
			PreparedStatement pstmt2 = conn.prepareStatement("select max(registration_id) from registration");
			ResultSet rs = pstmt2.executeQuery();
			rs.next();
			int registration_id = rs.getInt(1);
			return registration_id;
			
		} catch (SQLException e) {
		e.printStackTrace();
		conn.rollback();
		}
		finally{
			conn.setAutoCommit(true);
		}
		return 0;
	}

	@Override
	public Customer getRegistrationDetails(int registrationId)  throws SQLException{
		try {
			PreparedStatement pstmt1 = conn.prepareStatement("SELECT * from registration where registration_id="+registrationId);
			ResultSet registrationRS = pstmt1.executeQuery();
			if(registrationRS.next()) {
			String customerName = registrationRS.getString("customer_name");
			String mobileNumber=registrationRS.getString("mobile_number");
			double registrationFee=registrationRS.getDouble("registrations_fee");
			int age=registrationRS.getInt("age");
			double actualFee=registrationRS.getDouble("actual_fee");
			Customer customer=new Customer(registrationId, customerName, mobileNumber, registrationFee, age, actualFee);
			return customer;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			conn.rollback();
			throw e;
		}
		finally{
			conn.setAutoCommit(true);
		}
		return null;
	
	}

}
